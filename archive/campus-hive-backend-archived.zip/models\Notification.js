import mongoose from "mongoose";

const notificationSchema = new mongoose.Schema(
  {
    recipient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    type: {
      type: String,
      enum: [
        "verification_pending",
        "verification_approved",
        "verification_rejected",
        "new_listing",
        "listing_approved",
        "listing_rejected",
        "price_drop",
        "order_update",
        "new_order",
        "new_follower",
        "new_review",
        "message",
        "messaging",
        "system",
      ],
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      required: true,
    },
    link: {
      type: String,
      default: "",
    },
    read: {
      type: Boolean,
      default: false,
    },
    metadata: {
      type: Object,
      default: {},
    },
    schemaVersion: {
      type: Number,
      default: 1,
      required: true,
      index: true,
    },
  },
  {
    timestamps: true,
    strict: true,
  }
);

notificationSchema.pre(["updateOne", "updateMany", "findOneAndUpdate", "findByIdAndUpdate"], function () {
  this.setOptions({ runValidators: true });
});

const Notification = mongoose.models.Notification || mongoose.model("Notification", notificationSchema);

export default Notification;
